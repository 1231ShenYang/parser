The folder 'parser_erik' contain the last version of the parser. 01/aug/2014. 
This version (Jo�o Erik's version) corrected some errors of the Adyess' version of the parser.
The zip file 'parser_adyess_with_changes.zip' contain the Adyess' version that was alterated by Jo�o Erik.
